#include "table_management.h"

void saveTableFile(struct Table *table, int count) {
    FILE *file = fopen(TABLE_FILE, "w");
    if (!file) {
        printf("Error opening table file for writing!\n");
        return;
    }
    for (int i = 0; i < count; i++) {
        fprintf(file, "%d %d %s %d\n", table[i].tableID, table[i].capacity, table[i].name, table[i].Availablity);
    }
    fclose(file);
}

int loadTable(struct Table *table) {
    FILE *file = fopen(TABLE_FILE, "r");
    if (!file) return 0;

    int count = 0;
    while (fscanf(file, "%d %d %29s %d", &table[count].tableID, &table[count].capacity, table[count].name, &table[count].Availablity) == 4) {
        count++;
    }
    fclose(file);
    return count;
}

void addTable(struct Table *table, int *count) {
    if (*count >= MAX_TABLE) {
        printf("No more space for new tables!\n");
        return;
    }

    struct Table newTable;
    newTable.tableID = (*count > 0) ? table[*count - 1].tableID + 1 : 1;
    printf("Enter Table Capacity: ");
    scanf("%d", &newTable.capacity);
    newTable.Availablity = 1; // Table is available by default
    printf("Enter Table Name: ");
    scanf("%29s", newTable.name);

    table[*count] = newTable;
    (*count)++;
    saveTableFile(table, *count);
    printf("Table added successfully!\n");
}

void modifyTable(struct Table *table, int count) {
    int T_ID;
    printf("Enter Table ID to modify: ");
    scanf("%d", &T_ID);

    for (int i = 0; i < count; i++) {
        if (table[i].tableID == T_ID) {
            printf("Enter new Capacity: ");
            scanf("%d", &table[i].capacity);
            printf("Enter new Table Name: ");
            scanf("%29s", table[i].name);
            saveTableFile(table, count);
            printf("Table details updated successfully!\n");
            return;
        }
    }
    printf("Table ID not found!\n");
}

void deleteTable(struct Table *table, int *count) {
    int T_ID;
    printf("Enter Table ID to delete: ");
    scanf("%d", &T_ID);

    for (int i = 0; i < *count; i++) {
        if (table[i].tableID == T_ID) {
            for (int j = i; j < *count - 1; j++) {
                table[j] = table[j + 1];
            }
            (*count)--;
            saveTableFile(table, *count);
            printf("Table deleted successfully!\n");
            return;
        }
    }
    printf("Table ID not found!\n");
}

void displayTables(struct Table *table, int count) {
    if (count == 0) {
        printf("No tables found!\n");
        return;
    }

    printf("Table List:\n");
    for (int i = 0; i < count; i++) {
        printf("ID: %d, Capacity: %d, Name: %s, Status: %s\n", 
               table[i].tableID, table[i].capacity, table[i].name, 
               table[i].Availablity ? "Available" : "Reserved");
    }
}