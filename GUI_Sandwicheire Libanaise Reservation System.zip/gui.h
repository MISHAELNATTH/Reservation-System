#ifndef GUI_H
#define GUI_H

#include <gtk/gtk.h>

void activate(GtkApplication *app, gpointer user_data);
void on_customer_management_clicked(GtkButton *button, gpointer user_data);
void on_add_customer_clicked(GtkButton *button, gpointer user_data);
void on_display_customers_clicked(GtkButton *button, gpointer user_data);
void on_modify_customer_clicked(GtkButton *button, gpointer user_data);
void on_delete_customer_clicked(GtkButton *button, gpointer user_data);
void on_add_customer_confirm(GtkButton *button, gpointer user_data);
void on_modify_customer_confirm(GtkButton *button, gpointer user_data);
void on_delete_customer_clicked(GtkButton *button, gpointer user_data);

void on_table_management_clicked(GtkButton *button, gpointer user_data);

void on_reservation_management_clicked(GtkButton *button, gpointer user_data);
#endif