#ifndef CUSTOMER_MANAGEMENT_H
#define CUSTOMER_MANAGEMENT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CUSTOMERS 10000
#define CUSTOMER_FILE "data/customers.txt"

struct Customer {
    int ID;
    char name[50];
    char phone[15];
    int VIP;
};

void saveCustomersToFile(struct Customer *customers, int count);
int loadCustomersFromFile(struct Customer *customers);
void addCustomer(struct Customer *customers, int *count, const char *name, const char *phone, int vip);
void modifyCustomer(struct Customer *customers, int count, int id, const char *name, const char *phone, int vip);
void deleteCustomer(struct Customer *customers, int *count);
void displayCustomers(struct Customer *customers, int count);

#endif