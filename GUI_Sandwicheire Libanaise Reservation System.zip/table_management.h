#ifndef TABLE_MANAGEMENT_H
#define TABLE_MANAGEMENT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TABLE 500
#define TABLE_FILE "data/Table.txt"

struct Table {
    int tableID;
    int capacity;
    int Availablity;
    char name[30];
};

void saveTableFile(struct Table *table, int count);
int loadTable(struct Table *table);
void addTable(struct Table *table, int *count);
void modifyTable(struct Table *table, int count);
void deleteTable(struct Table *table, int *count);
void displayTables(struct Table *table, int count);

#endif