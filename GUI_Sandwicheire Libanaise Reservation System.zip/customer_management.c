#include "customer_management.h"

void saveCustomersToFile(struct Customer *customers, int count) {
    FILE *file = fopen(CUSTOMER_FILE, "a");
    if (!file) {
        printf("Error opening customer file for writing!\n");
        return;
    }
    for (int i = 0; i < count; i++) {
        fprintf(file, "%d %s %s %d\n", customers[i].ID, customers[i].name, customers[i].phone, customers[i].VIP);
    }
    fclose(file);
}

int loadCustomersFromFile(struct Customer *customers) {
    FILE *file = fopen(CUSTOMER_FILE, "r");
    if (!file) return 0;

    int count = 0;
    while (fscanf(file, "%d %49s %14s %d", &customers[count].ID, customers[count].name, customers[count].phone, &customers[count].VIP) == 4) {
        count++;
    }
    fclose(file);
    return count;
}

void addCustomer(struct Customer *customers, int *count, const char *name, const char *phone, int vip) {
    if (*count >= MAX_CUSTOMERS) {
        printf("Customer list is full!\n");
        return;
    }

    struct Customer newCustomer;
    newCustomer.ID = (*count > 0) ? customers[*count - 1].ID + 1 : 1;
    strncpy(newCustomer.name, name, 49);
    strncpy(newCustomer.phone, phone, 14);
    newCustomer.VIP = vip;

    // printf("Enter customer name: ");
    // scanf("%49s", newCustomer.name);
    // printf("Enter phone number: ");
    // scanf("%14s", newCustomer.phone);
    // printf("Is the customer VIP? (1 for Yes, 0 for No): ");
    // scanf("%d", &newCustomer.VIP);

    customers[*count] = newCustomer;
    (*count)++;
    saveCustomersToFile(customers, *count);
    printf("Customer added successfully!\n");
}

void modifyCustomer(struct Customer *customers, int count, int id, const char *name, const char *phone, int vip) {
    for (int i = 0; i < count; i++) {
        if (customers[i].ID == id) {
            strncpy(customers[i].name, name, 49);
            strncpy(customers[i].phone, phone, 14);
            customers[i].VIP = vip;
            break;
        }
    }
}

int delete_customer_from_backend(int customer_id) {
    struct Customer customers[MAX_CUSTOMERS];
    int customer_count = loadCustomersFromFile(customers);

    for (int i = 0; i < customer_count; i++) {
        if (customers[i].ID == customer_id) {
            // Shift all elements after the deleted customer
            for (int j = i; j < customer_count - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customer_count--;
            saveCustomersToFile(customers, customer_count);
            return 0; // Success
        }
    }

    return -1; // Customer not found
}
void displayCustomers(struct Customer *customers, int count) {
    if (count == 0) {
        printf("No customers found!\n");
        return;
    }
    // Bubble sort for alphabetical order
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {
            if (strcmp(customers[i].name, customers[j].name) > 0) {
                struct Customer temp = customers[i];
                customers[i] = customers[j];
                customers[j] = temp;
            }
        }
    }

    printf("Customer List:\n");
    for (int i = 0; i < count; i++) {
        printf("ID: %d, Name: %s, Phone: %s, VIP: %s\n", 
               customers[i].ID, customers[i].name, customers[i].phone, 
               customers[i].VIP ? "Yes" : "No");
    }
}