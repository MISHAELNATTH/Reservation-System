#include "gui.h"
#include "customer_management.h"
#include <gtk/gtk.h>  // Ensure GTK4 headers are included
// #include "table_management.h"
// #include "reservation_management.h"

#include "gui.h"
#include "customer_management.h"
#include <gtk/gtk.h>  // Ensure GTK4 headers are included

// Function to hide the message
gboolean hide_message(GtkWidget *revealer) {
    gtk_revealer_set_reveal_child(GTK_REVEALER(revealer), FALSE);
    return FALSE;  // Return FALSE to stop the timeout
}


// Function to handle the "Add Customer" button click
void on_add_customer_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *dialog;
    GtkWidget *grid;
    GtkWidget *name_entry;
    GtkWidget *phone_entry;
    GtkWidget *vip_check;
    GtkWidget *add_button;
    GtkWidget *cancel_button;

    // Create a new dialog window
    dialog = gtk_window_new();
    gtk_window_set_title(GTK_WINDOW(dialog), "Add Customer");
    gtk_window_set_default_size(GTK_WINDOW(dialog), 300, 200);

    // Create a grid to arrange widgets
    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
    gtk_window_set_child(GTK_WINDOW(dialog), grid);

    // Add input fields
    name_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(name_entry), "Enter Name");
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Name:"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), name_entry, 1, 0, 1, 1);

    phone_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(phone_entry), "Enter Phone Number");
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Phone:"), 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), phone_entry, 1, 1, 1, 1);

    vip_check = gtk_check_button_new_with_label("VIP Customer");
    gtk_grid_attach(GTK_GRID(grid), vip_check, 0, 2, 2, 1);

    // Add buttons
    add_button = gtk_button_new_with_label("Add");
    gtk_grid_attach(GTK_GRID(grid), add_button, 0, 3, 1, 1);

    cancel_button = gtk_button_new_with_label("Cancel");
    gtk_grid_attach(GTK_GRID(grid), cancel_button, 1, 3, 1, 1);

    // Pass the customers array and customerCount to the dialog
    g_object_set_data(G_OBJECT(dialog), "customers", user_data);
    g_object_set_data(G_OBJECT(dialog), "customerCount", (gpointer)((struct Customer *)user_data + MAX_CUSTOMERS));

    // Connect button signals
    g_signal_connect_swapped(cancel_button, "clicked", G_CALLBACK(gtk_window_destroy), dialog);
    g_signal_connect(add_button, "clicked", G_CALLBACK(on_add_customer_confirm), dialog);

    // Show the dialog
    gtk_widget_set_visible(dialog, TRUE);
}

void on_add_customer_confirm(GtkButton *button, gpointer user_data) {
    GtkWidget *dialog = GTK_WIDGET(user_data);
    GtkWidget *grid = gtk_window_get_child(GTK_WINDOW(dialog));
    GtkWidget *name_entry = gtk_grid_get_child_at(GTK_GRID(grid), 1, 0);
    GtkWidget *phone_entry = gtk_grid_get_child_at(GTK_GRID(grid), 1, 1);
    GtkWidget *vip_check = gtk_grid_get_child_at(GTK_GRID(grid), 0, 2);

    // Get the text from the entry widgets
    GtkEntryBuffer *name_buffer = gtk_entry_get_buffer(GTK_ENTRY(name_entry));
    GtkEntryBuffer *phone_buffer = gtk_entry_get_buffer(GTK_ENTRY(phone_entry));
    const char *name = gtk_entry_buffer_get_text(name_buffer);
    const char *phone = gtk_entry_buffer_get_text(phone_buffer);
    int vip = gtk_check_button_get_active(GTK_CHECK_BUTTON(vip_check));

    // Get the customers array and customerCount from the dialog
    struct Customer *customers = (struct Customer *)g_object_get_data(G_OBJECT(dialog), "customers");
    int *customerCount = (int *)g_object_get_data(G_OBJECT(dialog), "customerCount");

    // Add the new customer to the array
    if (*customerCount < MAX_CUSTOMERS) {
        struct Customer newCustomer;
        newCustomer.ID = (*customerCount > 0) ? customers[*customerCount - 1].ID + 1 : 1;
        strncpy(newCustomer.name, name, 49);
        strncpy(newCustomer.phone, phone, 14);
        newCustomer.VIP = vip;

        customers[*customerCount] = newCustomer;
        (*customerCount)++;

        // Save the updated customer list to the file
        saveCustomersToFile(customers, *customerCount);

        printf("Customer added successfully: Name=%s, Phone=%s, VIP=%d\n", name, phone, vip);
    } else {
        printf("Customer list is full!\n");
    }

    // Close the dialog
    gtk_window_destroy(GTK_WINDOW(dialog));
}

// Function to handle the "Display Customers" button click
void on_display_customers_clicked(GtkButton *button, gpointer user_data) {
    // Cast the button to GtkWidget *
    GtkWidget *window = gtk_widget_get_ancestor(GTK_WIDGET(button), GTK_TYPE_WINDOW);
    GtkWidget *text_view = GTK_WIDGET(g_object_get_data(G_OBJECT(window), "text_view"));
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));

    // Clear the text view
    gtk_text_buffer_set_text(buffer, "", -1);

    // Get the customers array and customerCount
    struct Customer *customers = (struct Customer *)user_data;
    int *customerCount = (int *)(customers + MAX_CUSTOMERS);

    // Display customer data in the text view
    GString *text = g_string_new("");
    for (int i = 0; i < *customerCount; i++) {
        g_string_append_printf(text, "ID: %d, Name: %s, Phone: %s, VIP: %s\n",
                               customers[i].ID, customers[i].name, customers[i].phone,
                               customers[i].VIP ? "Yes" : "No");
    }

    // Set the text in the text view
    gtk_text_buffer_set_text(buffer, text->str, -1);

    // Free the GString
    g_string_free(text, TRUE);
}

void on_modify_customer_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *dialog;
    GtkWidget *grid;
    GtkWidget *id_entry;
    GtkWidget *name_entry;
    GtkWidget *phone_entry;
    GtkWidget *vip_check;
    GtkWidget *modify_button;
    GtkWidget *cancel_button;

    // Create a new dialog window
    dialog = gtk_window_new();
    gtk_window_set_title(GTK_WINDOW(dialog), "Modify Customer");
    gtk_window_set_default_size(GTK_WINDOW(dialog), 300, 200);

    // Create a grid to arrange widgets
    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
    gtk_window_set_child(GTK_WINDOW(dialog), grid);

    // Add input fields
    id_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(id_entry), "Enter Customer ID");
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Customer ID:"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), id_entry, 1, 0, 1, 1);

    name_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(name_entry), "Enter New Name");
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("New Name:"), 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), name_entry, 1, 1, 1, 1);

    phone_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(phone_entry), "Enter New Phone Number");
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("New Phone:"), 0, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), phone_entry, 1, 2, 1, 1);

    vip_check = gtk_check_button_new_with_label("VIP Customer");
    gtk_grid_attach(GTK_GRID(grid), vip_check, 0, 3, 2, 1);

    // Add buttons
    modify_button = gtk_button_new_with_label("Modify");
    gtk_grid_attach(GTK_GRID(grid), modify_button, 0, 4, 1, 1);

    cancel_button = gtk_button_new_with_label("Cancel");
    gtk_grid_attach(GTK_GRID(grid), cancel_button, 1, 4, 1, 1);

    // Pass the customers array and customerCount to the dialog
    g_object_set_data(G_OBJECT(dialog), "customers", user_data);
    g_object_set_data(G_OBJECT(dialog), "customerCount", (gpointer)((struct Customer *)user_data + MAX_CUSTOMERS));

    // Connect button signals
    g_signal_connect_swapped(cancel_button, "clicked", G_CALLBACK(gtk_window_destroy), dialog);
    g_signal_connect(modify_button, "clicked", G_CALLBACK(on_modify_customer_confirm), dialog);

    // Show the dialog
    gtk_widget_set_visible(dialog, TRUE);
}

void on_modify_customer_confirm(GtkButton *button, gpointer user_data) {
    GtkWidget *dialog = GTK_WIDGET(user_data);
    GtkWidget *grid = gtk_window_get_child(GTK_WINDOW(dialog));
    GtkWidget *id_entry = gtk_grid_get_child_at(GTK_GRID(grid), 1, 0);
    GtkWidget *name_entry = gtk_grid_get_child_at(GTK_GRID(grid), 1, 1);
    GtkWidget *phone_entry = gtk_grid_get_child_at(GTK_GRID(grid), 1, 2);
    GtkWidget *vip_check = gtk_grid_get_child_at(GTK_GRID(grid), 0, 3);

    // Get the entry buffers
    GtkEntryBuffer *id_buffer = gtk_entry_get_buffer(GTK_ENTRY(id_entry));
    GtkEntryBuffer *name_buffer = gtk_entry_get_buffer(GTK_ENTRY(name_entry));
    GtkEntryBuffer *phone_buffer = gtk_entry_get_buffer(GTK_ENTRY(phone_entry));

    // Get the text from the entry buffers
    const char *id_str = gtk_entry_buffer_get_text(id_buffer);
    const char *name = gtk_entry_buffer_get_text(name_buffer);
    const char *phone = gtk_entry_buffer_get_text(phone_buffer);
    int vip = gtk_check_button_get_active(GTK_CHECK_BUTTON(vip_check));

    // Convert the ID string to an integer
    int id = atoi(id_str);

    // Get the customers array and customerCount from the dialog
    struct Customer *customers = (struct Customer *)g_object_get_data(G_OBJECT(dialog), "customers");
    int *customerCount = (int *)g_object_get_data(G_OBJECT(dialog), "customerCount");

    // Check if the customer ID exists
    int found = 0;
    for (int i = 0; i < *customerCount; i++) {
        if (customers[i].ID == id) {
            strncpy(customers[i].name, name, 49);
            strncpy(customers[i].phone, phone, 14);
            customers[i].VIP = vip;

            // Save the updated customer list to the file
            saveCustomersToFile(customers, *customerCount);

            printf("Customer modified successfully: ID=%d, Name=%s, Phone=%s, VIP=%d\n", id, name, phone, vip);
            found = 1;
            break;
        }
    }

    // If the customer ID was not found, show a message
    if (!found) {
        GtkWidget *window = gtk_widget_get_ancestor(dialog, GTK_TYPE_WINDOW);
        GtkWidget *revealer = GTK_WIDGET(g_object_get_data(G_OBJECT(window), "revealer"));
        GtkWidget *message_label = GTK_WIDGET(g_object_get_data(G_OBJECT(window), "message_label"));

        if (revealer && GTK_IS_REVEALER(revealer)) {
            // Set the message text
            gtk_label_set_text(GTK_LABEL(message_label), "Customer not found!");

            // Show the message
            gtk_revealer_set_reveal_child(GTK_REVEALER(revealer), TRUE);

            // Hide the message after 10 seconds
            g_timeout_add_seconds(10, (GSourceFunc)hide_message, revealer);
        } else {
            printf("Error: Revealer is not valid!\n");
        }
    }

    // Close the dialog
    gtk_window_destroy(GTK_WINDOW(dialog));
}

// Function to handle the "Delete Customer" button click
void on_delete_customer_clicked(GtkButton *button, gpointer user_data) {
    // Placeholder for delete customer functionality
    printf("Delete Customer clicked\n");
}

void on_customer_management_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *window;
    GtkWidget *grid;
    GtkWidget *add_button;
    GtkWidget *display_button;
    GtkWidget *modify_button;
    GtkWidget *delete_button;
    GtkWidget *text_view;
    GtkWidget *scrolled_window;
    GtkWidget *message_label;
    GtkWidget *revealer;

    // Create a new window for Customer Management
    window = gtk_window_new();
    gtk_window_set_title(GTK_WINDOW(window), "Customer Management");
    gtk_window_set_default_size(GTK_WINDOW(window), 800, 600);

    // Create a grid to arrange widgets
    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 10);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 10);
    gtk_window_set_child(GTK_WINDOW(window), grid);

    // Add buttons for each customer management function
    add_button = gtk_button_new_with_label("Add Customer");
    g_signal_connect(add_button, "clicked", G_CALLBACK(on_add_customer_clicked), user_data);
    gtk_grid_attach(GTK_GRID(grid), add_button, 0, 0, 1, 1);

    display_button = gtk_button_new_with_label("Display Customers");
    g_signal_connect(display_button, "clicked", G_CALLBACK(on_display_customers_clicked), user_data);
    gtk_grid_attach(GTK_GRID(grid), display_button, 1, 0, 1, 1);

    modify_button = gtk_button_new_with_label("Modify Customer");
    g_signal_connect(modify_button, "clicked", G_CALLBACK(on_modify_customer_clicked), user_data);
    gtk_grid_attach(GTK_GRID(grid), modify_button, 0, 1, 1, 1);

    delete_button = gtk_button_new_with_label("Delete Customer");
    g_signal_connect(delete_button, "clicked", G_CALLBACK(on_delete_customer_clicked), user_data);
    gtk_grid_attach(GTK_GRID(grid), delete_button, 1, 1, 1, 1);

    // Add a text view to display customer data
    text_view = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(text_view), FALSE);
    scrolled_window = gtk_scrolled_window_new();
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(scrolled_window), text_view);
    gtk_widget_set_size_request(scrolled_window, 750, 500);
    gtk_grid_attach(GTK_GRID(grid), scrolled_window, 0, 2, 2, 1);

    // Add a message label and revealer
    message_label = gtk_label_new("");
    revealer = gtk_revealer_new();
    gtk_revealer_set_child(GTK_REVEALER(revealer), message_label);
    gtk_revealer_set_transition_type(GTK_REVEALER(revealer), GTK_REVEALER_TRANSITION_TYPE_SLIDE_UP);
    gtk_revealer_set_transition_duration(GTK_REVEALER(revealer), 500);  // 500ms animation
    gtk_grid_attach(GTK_GRID(grid), revealer, 0, 3, 2, 1);

    // Store the text view and revealer in the window for later use
    g_object_set_data(G_OBJECT(window), "text_view", text_view);
    g_object_set_data(G_OBJECT(window), "revealer", revealer);
    g_object_set_data(G_OBJECT(window), "message_label", message_label);

    // Show the window
    gtk_widget_set_visible(window, TRUE);
}

void activate(GtkApplication *app, gpointer user_data) {
    GtkWidget *window;
    GtkWidget *grid;
    GtkWidget *button;

    // Extract customers and customerCount from user_data
    gpointer *data = (gpointer *)user_data;
    struct Customer *customers = (struct Customer *)data[0];
    int *customerCount = (int *)data[1];

    // Create the main window
    window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Restaurant Reservation System");
    gtk_window_set_default_size(GTK_WINDOW(window), 800, 600);

    // Create a grid to arrange widgets
    grid = gtk_grid_new();
    gtk_window_set_child(GTK_WINDOW(window), grid);

    // Add buttons for each management module
    button = gtk_button_new_with_label("Customer Management");
    g_signal_connect(button, "clicked", G_CALLBACK(on_customer_management_clicked), user_data);
    gtk_grid_attach(GTK_GRID(grid), button, 0, 0, 1, 1);

    button = gtk_button_new_with_label("Table Management");
    g_signal_connect(button, "clicked", G_CALLBACK(on_table_management_clicked), user_data);
    gtk_grid_attach(GTK_GRID(grid), button, 1, 0, 1, 1);

    button = gtk_button_new_with_label("Reservation Management");
    g_signal_connect(button, "clicked", G_CALLBACK(on_reservation_management_clicked), user_data);
    gtk_grid_attach(GTK_GRID(grid), button, 2, 0, 1, 1);

    // Show the window
    gtk_widget_set_visible(window, TRUE);
}

// Rest of your gui.c code...

void on_table_management_clicked(GtkButton *button, gpointer user_data) {
    // Placeholder for table management functionality
    printf("Table Management clicked\n");

    // You can add code here to open a new window for table management
}

void on_reservation_management_clicked(GtkButton *button, gpointer user_data) {
    // Placeholder for reservation management functionality
    printf("Reservation Management clicked\n");

    // You can add code here to open a new window for reservation management
}




