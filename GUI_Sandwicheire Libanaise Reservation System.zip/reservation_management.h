#ifndef RESERVATION_MANAGEMENT_H
#define RESERVATION_MANAGEMENT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "customer_management.h"
#include "table_management.h"

#define MAX_RESERVATIONS 1000
#define RESERVATION_FILE "data/reservations.txt"


struct Reservation {
    int reservationID;
    int customerID;
    int tableID;
    char date[15];
    char time[10];
};

void saveReservationsToFile(struct Reservation *reservations, int count);
int loadReservationsFromFile(struct Reservation *reservations);
void addReservation(struct Reservation *reservations, int *resCount, struct Customer *customers, int custCount, struct Table *tables, int tableCount);
void cancelReservation(struct Reservation *reservations, int *resCount, struct Table *tables, int tableCount);
void displayReservations(struct Reservation *reservations, int resCount);
void displayCustomersWithReservations(struct Reservation *reservations, int resCount, struct Customer *customers, int custCount);

#endif