#include <gtk/gtk.h>
#include "gui.h"
#include "customer_management.h"
#include <sys/stat.h>

int main(int argc, char **argv) {
    GtkApplication *app;
    int status;

    // // Create the data directory if it doesn't exist
    mkdir("data");

    // Initialize GTK application
    app = gtk_application_new("org.example.RestaurantReservation", G_APPLICATION_DEFAULT_FLAGS);

    struct Customer customers[MAX_CUSTOMERS];
    int customerCount = loadCustomersFromFile(customers);

    // Pass customers and customerCount to the activate function
    gpointer user_data[2];
    user_data[0] = customers;
    user_data[1] = &customerCount;

    // Connect the activate function to the "activate" signal
    g_signal_connect(app, "activate", G_CALLBACK(activate), customers);

    // Run the application
    status = g_application_run(G_APPLICATION(app), argc, argv);

    // Clean up
    g_object_unref(app);

    return status;
}