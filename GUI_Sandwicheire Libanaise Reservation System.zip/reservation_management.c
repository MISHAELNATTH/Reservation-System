#include "reservation_management.h"
#include "customer_management.h"
#include "table_management.h"

void saveReservationsToFile(struct Reservation *reservations, int count) {
    FILE *file = fopen(RESERVATION_FILE, "w");
    if (!file) {
        printf("Error opening reservation file for writing!\n");
        return;
    }
    for (int i = 0; i < count; i++) {
        fprintf(file, "%d %d %d %s %s\n", 
                reservations[i].reservationID, reservations[i].customerID, 
                reservations[i].tableID, reservations[i].date, reservations[i].time);
    }
    fclose(file);
}

int loadReservationsFromFile(struct Reservation *reservations) {
    FILE *file = fopen(RESERVATION_FILE, "r");
    if (!file) return 0;

    int count = 0;
    while (fscanf(file, "%d %d %d %14s %9s", 
                  &reservations[count].reservationID, &reservations[count].customerID, 
                  &reservations[count].tableID, reservations[count].date, 
                  reservations[count].time) == 5) {
        count++;
    }
    fclose(file);
    return count;
}

void addReservation(struct Reservation *reservations, int *resCount, 
                    struct Customer *customers, int custCount, 
                    struct Table *tables, int tableCount) {
    if (*resCount >= MAX_RESERVATIONS) {
        printf("Reservation list is full!\n");
        return;
    }

    int custID, tableID;
    char date[15], time[10];

    printf("Enter Customer ID for reservation: ");
    scanf("%d", &custID);
    // Verify customer exists
    int custFound = 0;
    for (int i = 0; i < custCount; i++) {
        if (customers[i].ID == custID) {
            custFound = 1;
            break;
        }
    }
    if (!custFound) {
        printf("Customer ID not found!\n");
        return;
    }

    printf("Enter Table ID to reserve: ");
    scanf("%d", &tableID);
    // Check table existence and availability
    int tableIndex = -1;
    for (int i = 0; i < tableCount; i++) {
        if (tables[i].tableID == tableID) {
            tableIndex = i;
            break;
        }
    }
    if (tableIndex == -1) {
        printf("Table ID not found!\n");
        return;
    }
    if (tables[tableIndex].Availablity == 0) {
        printf("Selected table is already reserved. Overbooking prevented!\n");
        return;
    }

    printf("Enter Reservation Date (YYYY-MM-DD): ");
    scanf("%14s", date);
    printf("Enter Reservation Time (HH:MM): ");
    scanf("%9s", time);

    struct Reservation newRes;
    newRes.reservationID = (*resCount > 0) ? reservations[*resCount - 1].reservationID + 1 : 1;
    newRes.customerID = custID;
    newRes.tableID = tableID;
    strcpy(newRes.date, date);
    strcpy(newRes.time, time);

    reservations[*resCount] = newRes;
    (*resCount)++;

    // Mark table as reserved
    tables[tableIndex].Availablity = 0;
    saveTableFile(tables, tableCount);
    saveReservationsToFile(reservations, *resCount);

    printf("Reservation booked successfully! Reservation ID: %d\n", newRes.reservationID);
}

void cancelReservation(struct Reservation *reservations, int *resCount, struct Table *tables, int tableCount){
    int resID;
    printf("Enter Reservation ID to cancel: ");
    scanf("%d", &resID);

    int found = 0;
    for (int i = 0; i < *resCount; i++) {
        if (reservations[i].reservationID == resID) {
            found = 1;
            int tableID = reservations[i].tableID;
            for (int j = 0; j < tableCount; j++) {
                if (tables[j].tableID == tableID) {
                    tables[j].Availablity = 1;
                    break;
                }
            }
            for (int j = i; j < *resCount - 1; j++) {
                reservations[j] = reservations[j + 1];
            }
            (*resCount)--;
            saveTableFile(tables, tableCount);
            saveReservationsToFile(reservations, *resCount);
            printf("Reservation cancelled successfully!\n");
            break;
        }
    }
    if (!found) {
        printf("Reservation ID not found!\n");
    }
}

void displayReservations(struct Reservation *reservations, int resCount) {
    if (resCount == 0) {
        printf("No reservations found!\n");
        return;
    }

    printf("Reservation List:\n");
    for (int i = 0; i < resCount; i++) {
        printf("Reservation ID: %d, Customer ID: %d, Table ID: %d, Date: %s, Time: %s\n", 
               reservations[i].reservationID, reservations[i].customerID, 
               reservations[i].tableID, reservations[i].date, reservations[i].time);
    }
}

void displayCustomersWithReservations(struct Reservation *reservations, int resCount, 
                                      struct Customer *customers, int custCount) {
    if (resCount == 0) {
        printf("No reservations to display customer information!\n");
        return;
    }

    printf("Customers with Reservations:\n");
    for (int i = 0; i < resCount; i++) {
        for (int j = 0; j < custCount; j++) {
            if (customers[j].ID == reservations[i].customerID) {
                printf("Customer ID: %d, Name: %s, Phone: %s, VIP: %s\n", 
                       customers[j].ID, customers[j].name, customers[j].phone, 
                       customers[j].VIP ? "Yes" : "No");
                break;
            }
        }
    }
}